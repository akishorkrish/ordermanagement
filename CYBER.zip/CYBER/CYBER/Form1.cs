﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CYBER
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            String fname = "NAME:" + textBox1.Text;
            String lname = "LAST NAME:" + textBox2.Text;
            int age = Convert.ToInt32(textBox3.Text);
            String place = "PLACE:" + textBox4.Text;
            String all = fname + lname + age + place;
            all.Trim();

            TextWriter txt = new StreamWriter("C:\\Users\\Rohsik_rio\\Documents\\Visual Studio 2012\\demo.txt");
            //C:\\Users\\Rohsik_rio\\Documents\\Visual Studio 2012
            txt.Write(all);
            txt.Close();
            MessageBox.Show("your values are stored successfully");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String name=  textBox5.Text;
            String food =  textBox6.Text;
            int qut = Convert.ToInt32(textBox7.Text);
           int amt ;// Convert.ToInt32(textBox8.Text);
            amt = qut * 50;
           
            String all = name + food + qut + amt;
            all.Trim();

            TextWriter txt = new StreamWriter("C:\\Users\\Rohsik_rio\\Documents\\Visual Studio 2012\\bill-management.txt");
            //C:\\Users\\Rohsik_rio\\Documents\\Visual Studio 2012
            txt.Write(all);
            txt.Close();
            MessageBox.Show("your values are stored successfully");
        }
    }
}
